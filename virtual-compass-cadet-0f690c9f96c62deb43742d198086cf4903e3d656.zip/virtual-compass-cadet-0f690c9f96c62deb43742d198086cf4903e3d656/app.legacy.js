console.info('[legacy] vietturis ielādējās');



/* app.legacy.js */
console.info('[legacy] vietturis ielādējās');
